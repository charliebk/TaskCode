# Guía de GitFlow — Run Configurations (IntelliJ IDEA)

Esta guía documenta el sistema de automatización Git-Flow integrado en IDEA mediante
scripts Bash y configuraciones XML de ejecución.

---

## Objetivo

Estandarizar el flujo de ramas del equipo sin necesidad de recordar comandos Git largos.
Un botón por operación, con validaciones, vista previa de cambios y log persistente.

---

## Dónde están los archivos

```
.idea/runConfigurations/
├── local_git-flow-actions/
│   ├── _gitflow-common.sh          ← Librería compartida (logging, git helpers)
│   ├── start-work.sh               ← GitFlow 01
│   ├── create-develop.sh           ← GitFlow 02
│   ├── create-feature.sh           ← GitFlow 03
│   ├── create-fix.sh               ← GitFlow 04
│   ├── create-release.sh           ← GitFlow 05
│   ├── create-hotfix.sh            ← GitFlow 06
│   ├── update-feature.sh           ← GitFlow 07
│   ├── update-fix.sh               ← GitFlow 08
│   ├── update-release.sh           ← GitFlow 09
│   ├── update-hotfix.sh            ← GitFlow 10
│   ├── merge-feature-to-develop.sh ← GitFlow 11
│   ├── merge-fix-to-develop.sh     ← GitFlow 12
│   ├── merge-release-to-main.sh    ← GitFlow 13
│   ├── merge-hotfix-to-main.sh     ← GitFlow 14
│   ├── diagnose-repo.sh            ← GitFlow 15
│   ├── pause-work.sh               ← GitFlow 16
│   ├── resume-work.sh              ← GitFlow 17
│   ├── recover-branch.sh           ← GitFlow 18
│   ├── abort-merge.sh              ← GitFlow 19
│   ├── mirror-to-remote.sh         ← GitFlow 20  [NUEVO]
│   ├── switch-working-remote.sh    ← GitFlow 21  [NUEVO]
│   └── push-back-to-remote.sh      ← GitFlow 22  [NUEVO]
├── local_GitFlow_01_Start_Work.xml
│   ... (un XML por cada script, del 01 al 22)
└── 000_GUIA-GITFLOW-RUNCONFIGURATIONS.md  ← este archivo
```

Todos estos archivos son **locales** (prefijo `local_` en los XML, carpeta `local_git-flow-actions`).
No se suben al repositorio. Son exclusivos de tu máquina.

---

## Requisitos

- Git instalado y en PATH.
- **Git Bash** disponible en `C:\Program Files\Git\bin\bash.exe`.
  Los XML apuntan a la ruta corta `C:/PROGRA~1/Git/bin/bash.exe` para evitar problemas
  con espacios en la ruta cuando IDEA lanza los scripts desde PowerShell.
- Estar dentro de un repositorio Git con remoto `origin` configurado.
- Repositorio con rama `develop` (se puede crear con GitFlow 02).

### Verificar que Git Bash está disponible

Desde PowerShell:
```powershell
& "C:\Program Files\Git\bin\bash.exe" --version
```
Debe mostrar algo como: `GNU bash, version 5.x.x`

### Si Git está instalado en otra ruta

Actualiza el campo `INTERPRETER_PATH` en todos los XML con la ruta correcta.
Para obtener la ruta 8.3 (sin espacios) de cualquier ejecutable:
```powershell
(New-Object -ComObject Scripting.FileSystemObject).GetFile("C:\tu\ruta\bash.exe").ShortPath
```

---

## Convención de nomenclatura de ramas

| Tipo | Formato | Ejemplo |
|------|---------|---------|
| Feature | `feature/<descripcion>` | `feature/S4.1-T4/review-update-code` |
| Fix | `fix/<descripcion>` | `fix/2001-error-bbox` |
| Hotfix | `hotfix/<descripcion>` | `hotfix/3001-crash-startup` |
| Release | `release/<version>` | `release/v1.2.0` |

Reglas: sin espacios, sin caracteres especiales, solo letras minúsculas, números, guion y barra.

---

## Parámetro `--push`

La mayoría de configuraciones XML incluyen `--push` en `SCRIPT_OPTIONS`.

- En scripts de **creación**: hace `git push -u origin <rama>` al crear la rama.
- En scripts de **update**: hace `git push origin <rama>` tras el merge de actualización.
- En scripts de **merge**: hace `git push origin <rama-destino>` tras el merge.
- En **Pause Work**: hace `git push origin <rama-actual>` tras guardar.

Si quieres ejecutar una operación sin subir a origin, edita el XML y vacía `SCRIPT_OPTIONS`.

---

## Funcionalidades automáticas

### Vista previa antes de mergear

Antes de cualquier `git merge`, todos los scripts muestran:

```
  Vista previa de cambios a mergear:
  --------------------------------------------------
  feature/1001-login  -->  develop
  --------------------------------------------------

  Commits que se van a integrar:
    abc1234 feat(login): añadir validación de token
    def5678 test(login): tests de integración JWT

  Ficheros afectados:
    src/main/java/.../LoginController.java  | +45
    src/main/java/.../AuthService.java      | +87
    ...
    12 files changed, 340 insertions(+), 28 deletions(-)

  Continuar con el merge? [S/n]:
```

Responde `S` (o Enter) para continuar, `n` para cancelar sin hacer nada.

### Gestión automática de workspace sucio

Si hay cambios locales sin commit al inicio de un workflow, el script pregunta:
```
Workspace no limpio antes de merge. Hacer commit local en la rama actual? Si/No:
```
- Si dices `Si`: pide un mensaje de commit, hace `git add -A` y crea el commit localmente.
- Si dices `No`: cancela la operación sin modificar nada.

### Log persistente

Cada ejecución escribe en `logs/gitflow/gitflow-YYYY-MM-DD.log` en la raíz del proyecto.
El directorio `logs/` está en `.gitignore` (no se comparte).

### Resumen final

Al terminar cada operación se muestra un bloque de resumen:
```
════════════════════════════════════════════════════
  [OK]  OPERACION : merge-feature-to-develop
        RESULTADO : COMPLETADO
        DURACION  : 4s
        DETALLE   : 7 commit(s) integrados en develop
════════════════════════════════════════════════════
```

### Modo offline

Si no hay conexión con `origin` (sin VPN, sin red), los scripts detectan la situación
y continúan en modo local cuando es posible, advirtiendo con `[WARN]`.

---

## Flujo completo — 22 pasos

```
INICIO DE JORNADA
  └─ 01 Start Work          ← sincronizar main y develop con origin

CREAR RAMA DE TRABAJO
  ├─ 02 Create Develop      ← (solo una vez al iniciar el proyecto)
  ├─ 03 Create Feature      ← nueva funcionalidad
  ├─ 04 Create Fix          ← corrección de bug en develop
  ├─ 05 Create Release      ← preparar versión
  └─ 06 Create Hotfix       ← corrección urgente en producción

TRABAJAR Y MANTENER ACTUALIZADO
  ├─ 07 Update Feature      ← traer cambios de develop a tu feature
  ├─ 08 Update Fix          ← traer cambios de develop a tu fix
  ├─ 09 Update Release      ← traer cambios de develop a tu release
  └─ 10 Update Hotfix       ← traer cambios de main a tu hotfix

INTEGRAR AL EQUIPO
  ├─ 11 Merge Feature → develop
  ├─ 12 Merge Fix → develop
  ├─ 13 Merge Release → main  (+ backmerge automático a develop)
  └─ 14 Merge Hotfix → main   (+ backmerge automático a develop)

HERRAMIENTAS DE APOYO
  ├─ 15 Diagnose Repo       ← estado completo del repo de un vistazo
  ├─ 16 Pause Work          ← guardar trabajo al final del día
  ├─ 17 Resume Work         ← retomar trabajo guardado
  ├─ 18 Recover Branch      ← recuperar rama perdida desde origin
  └─ 19 Abort Merge         ← cancelar un merge o rebase en curso

MIGRACIÓN ENTRE REMOTOS (nuevas)
  ├─ 20 Mirror to Remote     ← copiar TODO el histórico a un GitLab destino
  ├─ 21 Switch Working Remote ← conmutar origin sin tocar los 19 scripts
  └─ 22 Push Back to Remote   ← devolver el trabajo al GitLab original
```

---

## 01) GitFlow 01 — Start Work

- **Para qué**: sincronizar las ramas base (`main`/`master` y `develop`) al inicio del día.
- **Script**: `start-work.sh`
- **Cuándo usarlo**: primera acción del día antes de tocar cualquier cosa.

### Qué hace

1. `git status --porcelain` — valida workspace limpio
2. `git fetch origin`
3. Detecta la rama principal (`main` o `master`) automáticamente
4. `git pull --ff-only origin <main>`
5. Si `origin/develop` existe: `git pull --ff-only origin develop`

---

## 02) GitFlow 02 — Create Develop

- **Para qué**: crear la rama `develop` desde la rama principal (una sola vez al iniciar el proyecto).
- **Script**: `create-develop.sh`
- **Opciones XML**: `--push`

### Qué hace

1. Valida workspace limpio
2. `git fetch origin`
3. Detecta y actualiza la rama principal
4. Si `develop` ya existe: `git merge --ff-only <main>` para actualizarla
5. Si no existe: `git checkout -b develop <main>`
6. Con `--push`: `git push -u origin develop`

---

## 03) GitFlow 03 — Create Feature

- **Para qué**: crear una nueva rama `feature/*` desde `develop`.
- **Script**: `create-feature.sh`
- **Entrada**: pide el nombre por prompt si no se pasa como argumento (ej: `S4.2-T1/nueva-funcionalidad`).
- **Opciones XML**: `--push`

### Qué hace

1. Valida workspace limpio
2. Normaliza el nombre a `feature/<nombre>`
3. `git fetch origin`
4. Checkout y pull de `develop`
5. `git checkout -b feature/<nombre> develop`
6. Con `--push`: `git push -u origin feature/<nombre>`

---

## 04) GitFlow 04 — Create Fix

- **Para qué**: crear rama `fix/*` desde `develop` para corregir un bug.
- **Script**: `create-fix.sh`
- **Entrada**: prompt (ej: `2001-error-bbox`).
- **Opciones XML**: `--push`

### Qué hace

1. Valida workspace limpio
2. Normaliza a `fix/<nombre>`
3. `git fetch origin` → checkout y pull de `develop`
4. `git checkout -b fix/<nombre> develop`
5. Con `--push`: `git push -u origin fix/<nombre>`

---

## 05) GitFlow 05 — Create Release

- **Para qué**: crear rama `release/*` desde `develop` para preparar una versión.
- **Script**: `create-release.sh`
- **Entrada**: prompt (ej: `v1.2.0`).
- **Opciones XML**: `--push`

### Qué hace

1. Valida workspace limpio
2. Normaliza a `release/<nombre>`
3. `git fetch origin` → checkout y pull de `develop`
4. `git checkout -b release/<nombre> develop`
5. Con `--push`: `git push -u origin release/<nombre>`

---

## 06) GitFlow 06 — Create Hotfix

- **Para qué**: crear rama `hotfix/*` directamente desde `main`/`master` para una corrección urgente en producción.
- **Script**: `create-hotfix.sh`
- **Entrada**: prompt (ej: `3001-crash-startup`).
- **Opciones XML**: `--push`

### Qué hace

1. Valida workspace limpio
2. Normaliza a `hotfix/<nombre>`
3. `git fetch origin`
4. Detecta y actualiza la rama principal (`main` o `master`)
5. `git checkout -b hotfix/<nombre> <main>`
6. Con `--push`: `git push -u origin hotfix/<nombre>`

---

## 07) GitFlow 07 — Update Feature from Develop

- **Para qué**: traer los cambios más recientes de `develop` a tu rama `feature/*`.
- **Script**: `update-feature.sh`
- **Entrada**: nombre de la feature (ej: `S4.1-T4/review-update-code`). Si no existe localmente se crea desde `origin`.
- **Opciones XML**: `--push`
- **Cuándo usarlo**: siempre antes de hacer el merge a develop (GitFlow 11).

### Qué hace

1. Valida workspace limpio (o pregunta si hacer commit local)
2. `git fetch origin`
3. Checkout y pull de `develop`
4. Checkout de `feature/<nombre>`
5. Muestra **vista previa** de los commits de develop que entrarán
6. Pide confirmación `[S/n]`
7. `git merge --no-ff develop -m "update(feature): develop -> feature/<nombre>"`
8. Con `--push`: `git push origin feature/<nombre>`

### Resolución de conflictos

Si aparecen conflictos:
- Resuélvelos en IDEA (marca como resueltos con el editor de conflictos).
- Para mantener la versión de `develop`: `git checkout --theirs <archivo>`
- Para mantener tu versión: `git checkout --ours <archivo>`
- Tras resolver todos: `git add <archivos>` y `git commit`

---

## 08) GitFlow 08 — Update Fix from Develop

- **Para qué**: traer los cambios de `develop` a tu rama `fix/*`.
- **Script**: `update-fix.sh`
- **Entrada**: nombre del fix (ej: `2001-error-bbox`).
- **Opciones XML**: `--push`

### Qué hace

Igual que GitFlow 07 pero para ramas `fix/*`.

---

## 09) GitFlow 09 — Update Release from Develop

- **Para qué**: traer los cambios de `develop` a tu rama `release/*`.
- **Script**: `update-release.sh`
- **Entrada**: nombre de la release (ej: `v1.2.0`).
- **Opciones XML**: `--push`

### Qué hace

Igual que GitFlow 07 pero para ramas `release/*`.

---

## 10) GitFlow 10 — Update Hotfix from Main

- **Para qué**: traer los cambios de `main`/`master` a tu rama `hotfix/*`.
- **Script**: `update-hotfix.sh`
- **Entrada**: nombre del hotfix (ej: `3001-crash-startup`).
- **Opciones XML**: `--push`

### Qué hace

1. Valida workspace limpio
2. `git fetch origin`
3. Detecta y actualiza la rama principal
4. Checkout de `hotfix/<nombre>`
5. Vista previa + confirmación
6. `git merge --no-ff <main> -m "update(hotfix): <main> -> hotfix/<nombre>"`
7. Con `--push`: `git push origin hotfix/<nombre>`

---

## 11) GitFlow 11 — Merge Feature to Develop

- **Para qué**: integrar tu feature terminada en `develop`.
- **Script**: `merge-feature-to-develop.sh`
- **Entrada**: nombre de la feature (ej: `S4.1-T4/review-update-code`).
- **Opciones XML**: `--push`
- **Prerrequisito**: ejecutar GitFlow 07 primero para evitar conflictos en `develop`.

### Qué hace

1. Valida workspace limpio (o pregunta si hacer commit local)
2. `git fetch origin`
3. Checkout y pull de `develop`
4. Si `feature/<nombre>` no existe local, la crea desde `origin/feature/<nombre>`
5. Vuelve a `develop`
6. Muestra **vista previa** de los commits de la feature que entrarán
7. Pide confirmación `[S/n]`
8. `git merge --no-ff feature/<nombre> -m "merge(feature): feature/<nombre> -> develop"`
9. Con `--push`: `git push origin develop`

---

## 12) GitFlow 12 — Merge Fix to Develop

- **Para qué**: integrar un fix terminado en `develop`.
- **Script**: `merge-fix-to-develop.sh`
- **Entrada**: nombre del fix.
- **Opciones XML**: `--push`

### Qué hace

Igual que GitFlow 11 pero para ramas `fix/*`.

---

## 13) GitFlow 13 — Merge Release to Main

- **Para qué**: integrar la release en `main`/`master` y hacer backmerge automático a `develop`.
- **Script**: `merge-release-to-main.sh`
- **Entrada**: nombre de la release (ej: `v1.2.0`).
- **Opciones XML**: `--push`

### Qué hace

1. Valida workspace limpio
2. `git fetch origin`
3. Detecta y actualiza la rama principal
4. Trae `release/<nombre>` local si solo existe en remoto
5. Vuelve a `<main>`
6. Vista previa + confirmación
7. `git merge --no-ff release/<nombre> -m "merge(release): release/<nombre> -> <main>"`
8. Crea tag automático: `git tag -a <nombre> -m "release: <nombre>"`
9. Backmerge: `git checkout develop` → `git merge --no-ff <main>`
10. Con `--push`: `git push origin <main>` + `git push origin develop` + `git push --tags`

---

## 14) GitFlow 14 — Merge Hotfix to Main

- **Para qué**: integrar un hotfix urgente en `main`/`master` y hacer backmerge a `develop`.
- **Script**: `merge-hotfix-to-main.sh`
- **Entrada**: nombre del hotfix.
- **Opciones XML**: `--push`

### Qué hace

Igual que GitFlow 13 pero para ramas `hotfix/*`.

---

## 15) GitFlow 15 — Diagnose Repo  ★ NUEVO

- **Para qué**: ver el estado completo del repositorio de un vistazo antes de empezar a trabajar.
- **Script**: `diagnose-repo.sh`
- **Opciones XML**: ninguna (solo lectura, no modifica nada).
- **Cuándo usarlo**: al abrir el proyecto, cuando algo "huele raro", antes de una operación crítica.

### Qué muestra

```
  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  DIAGNÓSTICO DEL REPOSITORIO
  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Rama actual      : feature/S4.1-T4/review-update-code
  Workspace        : ✓ LIMPIO
  Remoto           : ✓ origin disponible
  Rama principal   : master
  Develop          : ✓ local + remoto
  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Estado vs origin/feature/...:
    ✓ Sincronizado
  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Stashes guardados: 0
  ✓  Sin operaciones en curso
  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## 16) GitFlow 16 — Pause Work  ★ NUEVO

- **Para qué**: guardar el trabajo de forma segura al final del día o antes de cambiar de contexto.
- **Script**: `pause-work.sh`
- **Opciones XML**: `--push`
- **Cuándo usarlo**: al terminar la jornada o antes de cambiar de tarea.

### Qué hace

1. Muestra la rama actual y los archivos modificados
2. Si el workspace está limpio: hace push directamente (si `--push`)
3. Si hay cambios sin guardar, pregunta:
   - **`commit`**: pide mensaje, `git add -A`, crea commit, opcionalmente push
   - **`stash`**: guarda con etiqueta `pause: <rama> <fecha>` para recuperarla con GitFlow 17
   - **`cancelar`**: no hace nada

---

## 17) GitFlow 17 — Resume Work  ★ NUEVO

- **Para qué**: retomar el trabajo en una rama previamente pausada.
- **Script**: `resume-work.sh`
- **Opciones XML**: ninguna (la rama se selecciona interactivamente).
- **Cuándo usarlo**: al empezar el día o al volver a una tarea interrumpida.

### Qué hace

1. Si no se pasa nombre de rama, muestra las ramas locales y pide selección
2. Comprueba que el workspace está limpio (si no, indica usar GitFlow 16 primero)
3. `git fetch origin`
4. Cambia a la rama seleccionada (la crea local si solo existe en origin)
5. `git pull --ff-only origin <rama>` (si tiene remoto)
6. Busca stash con etiqueta `pause: <rama>` y ofrece aplicarlo
7. Muestra el estado final del workspace

---

## 18) GitFlow 18 — Recover Branch from Origin  ★ NUEVO

- **Para qué**: recuperar una rama local que se perdió, borró accidentalmente o no existe localmente.
- **Script**: `recover-branch.sh`
- **Opciones XML**: ninguna (la rama se selecciona interactivamente).
- **Cuándo usarlo**: cuando git dice que una rama no existe localmente pero sabes que está en origin.

### Qué hace

1. `git fetch origin`
2. Si no se pasa nombre de rama, muestra todas las ramas de origin y pide selección
3. Verifica que la rama existe en `origin`
4. Si ya existe localmente: pide confirmación para sobreescribir
5. `git checkout -b <nombre> origin/<nombre>` con tracking configurado automáticamente
6. Muestra los últimos commits de la rama recuperada

---

## 19) GitFlow 19 — Abort Merge  ★ NUEVO

- **Para qué**: cancelar un merge o rebase en curso y volver al estado anterior.
- **Script**: `abort-merge.sh`
- **Opciones XML**: ninguna.
- **Cuándo usarlo**: cuando un merge produce conflictos que no quieres resolver ahora,
  o cuando lanzaste un merge por error.

### Qué hace

1. Detecta si hay un merge en curso (`.git/MERGE_HEAD`)
2. Detecta si hay un rebase en curso (`.git/rebase-merge` o `.git/rebase-apply`)
3. Si no hay nada en curso: lo informa y termina
4. Muestra qué operación está en curso y los archivos en conflicto (si los hay)
5. Pide confirmación `[s/N]`
6. Ejecuta `git merge --abort` o `git rebase --abort` según corresponda
7. Deja el workspace exactamente como estaba antes de la operación

---

## 20) GitFlow 20 — Mirror to Remote  ★ NUEVO

- **Para qué**: copiar TODO el histórico del `origin` actual (ramas, tags) a un nuevo remoto. Operación **one-shot** para migrar el repo a otro GitLab/GitHub manteniendo la historia 1:1.
- **Script**: `mirror-to-remote.sh`
- **Opciones XML**: ninguna (la URL y el nombre del remoto se piden por prompt).
- **Cuándo usarlo**: para sacar copia espejo del repo a tu GitLab personal mientras se solucionan los problemas del GitLab corporativo, o para migrar definitivamente a otra instancia.
- **Prerrequisitos**:
  - Conexión a `origin` (VPN/credenciales).
  - Repositorio destino **creado y vacío** en el GitLab/GitHub de destino (sin README, sin .gitignore, sin licencia).
  - Token con scope `write_repository` (HTTPS) o clave SSH registrada en la cuenta destino.

### Qué hace

1. Lee la URL del `origin` actual.
2. Pide el **nombre** del nuevo remoto (sugerido: `gitlab-personal`).
3. Pide la **URL** del repo destino (si el remoto ya existe, ofrece reutilizar su URL).
4. Avisa si el repo tiene **Git LFS** o **submodules** (requieren pasos extra manuales).
5. `git fetch --prune --tags origin` para tener la historia local completamente al día.
6. Verifica que el destino está **vacío**. Si tiene ramas, pide confirmación explícita.
7. Muestra resumen: número de ramas, número de tags, último commit. Pide confirmación.
8. `git push <nombre> --all` y `git push <nombre> --tags`.
9. Resumen final con las URLs de ambos remotos y sugerencia de ejecutar GitFlow 21.

### Resultado

Dos remotos configurados: `origin` (corporativo, sin tocar) y `<nombre>` (personal, con copia 1:1). Los SHAs de commits son **idénticos** en ambos, así que cualquier `push` futuro al original será fast-forward natural.

---

## 21) GitFlow 21 — Switch Working Remote  ★ NUEVO

- **Para qué**: conmutar qué remoto se llama `origin` sin tocar los 19 scripts existentes. Renombra el `origin` actual a un alias de backup y promueve otro remoto a `origin`.
- **Script**: `switch-working-remote.sh`
- **Opciones XML**: ninguna (selección interactiva).
- **Cuándo usarlo**: tras ejecutar GitFlow 20, cuando quieras que los 19 scripts existentes (Start Work, Create Feature, Merge, etc.) trabajen contra el GitLab personal.

### Qué hace

1. Muestra los remotos configurados.
2. Lista los remotos disponibles distintos de `origin` y pide cuál promover.
3. Pide nombre del alias de backup para el `origin` actual (sugerido: `gitlab-empresa`).
4. Muestra ANTES → DESPUÉS con las URLs. Pide confirmación explícita.
5. Renombra `origin` → `<backup>` y `<elegido>` → `origin`.
6. `git fetch --prune --tags origin` para refrescar tracking refs.
7. Reconfigura el `upstream` de la rama actual si existe en el nuevo origin.

### Reversible

Para volver al GitLab corporativo, reejecuta el script y promueve el remoto de backup:
```
GitFlow 21 → promover 'gitlab-empresa' a origin → guardar el actual como 'gitlab-personal'
```

### Tras la conmutación

- `git push origin develop` envía al GitLab personal.
- Los 19 scripts hablan transparentemente con el GitLab personal.
- `git push gitlab-empresa <rama>` sigue siendo posible cuando vuelvas a tener VPN.

---

## 22) GitFlow 22 — Push Back to Remote  ★ NUEVO

- **Para qué**: devolver el trabajo al GitLab corporativo cuando se quiera retomar el trabajo allí. El script soporta **dos modos**: aditivo (conservador) y mirror (destructivo).
- **Script**: `push-back-to-remote.sh`
- **Opciones XML**: ninguna (selección interactiva).
- **Cuándo usarlo**: cuando se arregle el problema en la empresa y quieras volcar el trabajo nuevo al GitLab corporativo.
- **Flags CLI opcionales**:
  - `--mode additive` / `--additive`
  - `--mode mirror` / `--mirror`
  - `--target <nombre-del-remoto>`
  - `--restore-as-origin`

### Modos disponibles

| Modo | Comando interno | Qué hace | Cuándo usarlo |
|------|-----------------|----------|---------------|
| **ADITIVO** (default) | `git push --all` + `git push --tags` | Envía ramas y tags. **No borra nada** del destino. Falla si hay divergencias non-fast-forward. | Caso normal: vuelves tras una pausa, conservas historia del destino. |
| **MIRROR** (opt-in) | `git push --mirror` | Sobreescribe el destino con espejo exacto de local. **Borra** ramas y tags que existan solo en destino. Force-push en divergencias. | Caso "substituir todo": el repo personal es la única verdad, el corporativo debe replicarlo exacto. |

### Qué hace (flujo común)

1. Lista los remotos configurados.
2. Sugiere automáticamente el primer remoto que reconozca como destino corporativo (`gitlab-empresa`, `gitlab-empresa-bak`, `gitlab-corporativo`, `origin-old`).
3. **Pregunta qué modo usar** si no se pasó por CLI.
4. Verifica conectividad con el destino.
5. `git fetch --prune --tags <destino>` para conocer su estado.
6. Detecta ramas con **divergencia** (commits en el destino que NO están en local).
7. **Solo en modo mirror**: detecta también ramas y tags que existen solo en el destino y se van a **borrar**.

### Modo ADITIVO — confirmación

Si hay divergencias, pide confirmación normal `[s/N]`. Si el usuario acepta, el push de las ramas divergentes fallará pero el resto se enviará.

Luego muestra el resumen estándar (`show_remote_summary`) y pide confirmación final.

### Modo MIRROR — DOBLE confirmación

Pantalla 1 — Preview destructivo:
```
  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    ATENCION: MODO MIRROR SELECCIONADO
    Se sobreescribira 'gitlab-empresa' con espejo EXACTO de local.
  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

  Ramas con commits del destino que se PERDERAN (force-overwrite):
    develop (local +12 / destino +3)

  Ramas que EXISTEN solo en destino y se BORRARAN (2):
    - feature/algo-que-hizo-otro
    - hotfix/parche-urgente

  Tags que EXISTEN solo en destino y se BORRARAN (1):
    - v1.4.2-rc1

  Esta accion es IRREVERSIBLE sobre el destino 'gitlab-empresa'.
  Si tu equipo IECA exige conservar ramas tras merge, este modo VIOLA esa politica.

  Continuar con el envio a 'gitlab-empresa'? [S/n]:
```

Pantalla 2 — Frase exacta:
```
  Para continuar, escribe exactamente la frase:
    BORRAR Y SUSTITUIR

  Confirmacion:
```

Si lo que escribes **no coincide letra a letra** (incluido el espaciado y las mayúsculas), la operación se aborta sin tocar nada.

### Resolver divergencias en modo aditivo

Si el script detecta divergencias y prefieres conservar la historia del destino, sigue este flujo manual antes de reintentar:

```bash
git checkout <rama-divergente>
git pull <destino> <rama-divergente>      # trae los commits del destino
# Resuelve conflictos si los hay
git push <destino> <rama-divergente>      # publica el merge
```

Y luego reejecuta GitFlow 22 en modo aditivo para el resto.

### Aviso sobre política IECA

La memoria del proyecto registra que la política IECA **prohíbe borrar ramas Git tras merge** para auditoría. **El modo mirror viola esa política** porque puede borrar ramas del destino. Usa modo mirror solo si tienes autorización explícita del responsable IECA o si el repo destino no está sujeto a esa política (ej.: GitLab personal de respaldo, no el corporativo).

---

## Apéndice — Procedimiento completo de migración temporal

Caso típico: el GitLab corporativo tiene problemas y quieres seguir trabajando en tu GitLab personal mientras se arregla. Cuando vuelva, devuelves todo el trabajo nuevo al corporativo.

### Checklist pre-migración

- [ ] Cuenta en GitLab destino (gitlab.com u otra instancia) con Personal Access Token de scope `write_repository`.
- [ ] Repositorio destino creado y **vacío** (sin README/licencia/.gitignore inicial).
- [ ] Conexión actual al GitLab corporativo verificada (VPN activa, fetch funciona).
- [ ] Workspace limpio (`git status` sin cambios).
- [ ] Sin secretos en el histórico que no debas migrar (revisar `git log -p | grep -E 'PASSWORD|SECRET|TOKEN'`). Rotar si los hay.
- [ ] Sin Git LFS o submodules (si los hay, plan B documentado en el aviso del script).

### Fase 1 — Salida del GitLab corporativo

```
GitFlow 20 Mirror to Remote
  → nombre: gitlab-personal
  → URL: https://gitlab.com/<tu-usuario>/cdau-services.git

GitFlow 21 Switch Working Remote
  → promover: gitlab-personal
  → backup como: gitlab-empresa
```

A partir de aquí, los 19 scripts trabajan contra GitLab personal.

### Fase 2 — Trabajo normal

Usa los 19 scripts como siempre (Create Feature, Merge, etc.). Todos los commits nuevos viven en GitLab personal. El GitLab corporativo queda congelado en el estado del momento de la migración.

### Fase 3 — Retorno al GitLab corporativo

Cuando se arregle el GitLab corporativo y quieras devolver el trabajo, elige modo según el caso:

**Caso A — sumar trabajo (recomendado, respeta auditoría IECA):**
```
GitFlow 22 Push Back to Remote
  → destino: gitlab-empresa
  → modo: 1 (aditivo)
  → (opcional --restore-as-origin para conmutar de vuelta)
```

**Caso B — sustituir todo (destructivo, requiere autorización IECA):**
```
GitFlow 22 Push Back to Remote
  → destino: gitlab-empresa
  → modo: 2 (mirror)
  → confirmar con frase exacta: BORRAR Y SUSTITUIR
```

El modo mirror BORRA del destino cualquier rama o tag que no exista en local. Úsalo solo si necesitas que el corporativo sea espejo exacto del personal y has comprobado que nadie ha tocado el corporativo durante tu ausencia.

Si después quieres que `origin` vuelva a ser el GitLab corporativo:

```
GitFlow 21 Switch Working Remote
  → promover: gitlab-empresa
  → backup como: gitlab-personal
```

### Notas importantes

- **MRs, issues, pipelines, ramas protegidas, variables CI/CD** no son Git: no se migran con estos scripts. Si los necesitas, mira la opción `Settings → General → Advanced → Export project` en GitLab (requiere versiones compatibles entre las dos instancias).
- **Logs**: los 3 scripts escriben en `logs/gitflow/gitflow-YYYY-MM-DD.log` igual que los anteriores. El directorio `logs/` está en `.gitignore`.
- **Política IECA de no borrar ramas**: GitFlow 20 hace `push --all`, que copia *todas* las `feature/*` históricas. Compatible con la política.
- **Coste de la primera ejecución**: en un repo grande (varios cientos de MB) el `push --all` inicial puede tardar varios minutos.

---

## Checklist rápido antes de ejecutar cualquier botón

- [ ] Sé en qué rama estoy (`GitFlow 15 Diagnose` si tengo dudas).
- [ ] El nombre de rama sigue el formato `tipo/descripcion`.
- [ ] Si hay cambios locales, decido si guardarlos antes (`GitFlow 16 Pause`).
- [ ] Para merge: ejecuté el Update correspondiente primero (07-10).
- [ ] Entiendo si la operación hará push automático (`--push` en el XML).

---

## Resolución de conflictos

Cuando un `update` o `merge` produce conflictos, git para y muestra los archivos en conflicto.

### Opciones desde terminal

```bash
# Mantener la versión que viene de fuera (develop/main):
git checkout --theirs <archivo>

# Mantener tu versión (rama actual):
git checkout --ours <archivo>

# Tras resolver todos los conflictos:
git add <archivos_resueltos>
git commit   # usa el mensaje de merge que git preparó
```

### Opción desde IDEA

Menú `Git → Resolve Conflicts` → selecciona cada archivo → elige qué versión mantener → marca como resuelto.

Si quieres cancelar todo y volver atrás: usa **GitFlow 19 Abort Merge**.

---

## Nota final

Para trabajo en equipo usa Merge Requests en GitLab para revisión y trazabilidad.
Estos scripts aceleran y estandarizan el flujo local; el MR añade la revisión del equipo.