# Flujo de Autenticación: Login-Frontend ↔ Sentidos-Frontend

## Arquitectura de Autenticación SSO

El sistema utiliza una arquitectura de Single Sign-On (SSO) basada en cookies compartidas entre dominios.

```
┌─────────────────────────────────────────────────────────────────┐
│                      Gateway Service (8085)                     │
│  - Punto de entrada único para todas las APIs                    │
│  - Valida tokens JWT en todas las peticiones                     │
└─────────────────────────────────────────────────────────────────┘
                                 ▲
                                 │
                                 │ JWT Token
                                 │
        ┌────────────────────────┼────────────────────────┐
        │                        │                        │
┌───────▼────────┐     ┌────────▼─────────┐     ┌────────▼─────────┐
│ Login-Frontend │     │Sentidos-Frontend│     │  Auth-Service    │
│   (5171)       │◄────│    (5172)        │─────│    (8081)        │
│                │     │                 │     │                 │
│ - Login form   │     │ - App principal │     │ - Genera JWT    │
│ - Redirección  │     │ - Verifica auth │     │ - Valida cred   │
└────────────────┘     └─────────────────┘     └─────────────────┘
```

## Flujo de Autenticación

### 1. Usuario accede a Sentidos-Frontend sin estar autenticado

1. Usuario navega a `http://localhost:5172` (Sentidos-Frontend)
2. Sentidos-Frontend verifica si existe cookie de sesión:
   - Si NO existe: Redirige a Login-Frontend
   - Si existe: Permite acceso

### 2. Usuario inicia sesión en Login-Frontend

1. Login-Frontend muestra formulario de login
2. Usuario introduce credenciales
3. Login-Frontend llama a Auth-Service vía Gateway:
   ```
   POST http://localhost:8085/auth/login
   ```
4. Auth-Service valida credenciales y genera JWT
5. Login-Frontend recibe JWT y:
   - Guarda JWT en cookie compartida (`SSO_LAST_APP_COOKIE`)
   - Guarda la app destino (sentidos) en cookie
   - Redirige a Sentidos-Frontend

### 3. Usuario accede a Sentidos-Frontend con sesión

1. Sentidos-Frontend verifica cookie de sesión
2. Si existe, obtiene JWT de la cookie
3. Cada petición API incluye JWT en header:
   ```
   Authorization: Bearer <JWT_TOKEN>
   ```
4. Gateway valida el JWT antes de pasar la petición a los microservicios

## Configuración de Cookies

Las cookies se configuran en `.env`:

```env
# Cookies globales para compartir entre apps del mismo dominio
APP_COOKIE_PATH=/
APP_SAME_DOMAIN=false  # false en desarrollo, true en producción
FRONTEND_ORIGIN=http://localhost:*
COOKIE_SECURE_BY_SSL=false  # false en desarrollo, true en producción

# SSO
SSO_LAST_APP_COOKIE=last_app
```

## URLs de Redirección

Configuradas en `.env`:

```env
# Login Frontend
FRONT_APP_LOGIN_URL=http://localhost:5171
FRONT_APP_LOGIN_CONTEXT=/

# Sentidos Frontend
FRONT_APP_SENTIDOS_URL=http://localhost:5172
FRONT_APP_SENTIDOS_CONTEXT=/

# Otras aplicaciones
FRONT_APP_MANTENIMIENTO_URL=http://localhost:5173
FRONT_APP_VISUALIZADOR_URL=http://localhost:5174
```

## Cómo Verificar el Flujo de Autenticación

### Paso 1: Arrancar todos los servicios

```powershell
.\start-all-services.ps1
```

### Paso 2: Verificar que todos los servicios están corriendo

Abre un navegador y verifica:
- `http://localhost:5171` → Login-Frontend
- `http://localhost:5172` → Sentidos-Frontend (debería redirigir a login)
- `http://localhost:8085/actuator/health` → Gateway health check

### Paso 3: Probar el flujo completo

1. **Acceder a Sentidos sin login:**
   - Navega a `http://localhost:5172`
   - Deberías ser redirigido automáticamente a `http://localhost:5171`

2. **Iniciar sesión:**
   - En Login-Frontend, introduce credenciales de prueba
   - Las credenciales deben existir en la base de datos
   - O usa el endpoint de desarrollo `/auth/dev/token` si está habilitado

3. **Verificar redirección:**
   - Después del login exitoso, deberías ser redirigido a `http://localhost:5172`
   - Sentidos-Frontend debería cargar sin pedir login nuevamente

4. **Verificar cookies:**
   - Abre DevTools → Application → Cookies
   - Deberías ver la cookie `last_app` con valor `sentidos`
   - Deberías ver la cookie de JWT

### Paso 4: Probar persistencia de sesión

1. Cierra la pestaña de Sentidos-Frontend
2. Abre nueva pestaña y navega a `http://localhost:5172`
3. Deberías acceder directamente sin pedir login (SSO funciona)

## Configuración de Desarrollo vs Producción

### Desarrollo
```env
APP_SAME_DOMAIN=false
COOKIE_SECURE_BY_SSL=false
FRONTEND_ORIGIN=http://localhost:*
```

### Producción
```env
APP_SAME_DOMAIN=true
COOKIE_SECURE_BY_SSL=true
FRONTEND_ORIGIN=https://*.callejerodeandalucia.es,https://*.iecatest.es
```

## Solución de Problemas Comunes

### Problema: Redirección infinita entre login y sentidos

**Causa:** Cookie no se está compartiendo entre dominios

**Solución:**
- Verifica que `APP_SAME_DOMAIN` esté configurado correctamente
- En desarrollo usa `false`, en producción usa `true`
- Verifica que `COOKIE_SECURE_BY_SSL` coincida con tu entorno (HTTP vs HTTPS)

### Problema: JWT no se guarda en cookie

**Causa:** Dominio de cookie no coincide

**Solución:**
- Verifica `FRONTEND_ORIGIN` en `.env`
- Asegúrate de que incluya tu dominio de desarrollo

### Problema: Gateway rechaza peticiones

**Causa:** JWT expirado o inválido

**Solución:**
- Verifica `JWT_EXPIRATION` en `.env` (en ms)
- Para desarrollo usa valores largos: `900000` (15 minutos)
- Verifica que el Gateway tenga las mismas claves JWT que Auth-Service

## Endpoints Clave

### Auth-Service
- `POST /auth/login` - Login tradicional
- `POST /auth/refresh` - Refrescar token
- `POST /auth/logout` - Logout
- `GET /auth/dev/token` - Generar token de desarrollo (solo si `DEV_TOKEN_GENERATOR_ENABLED=true`)

### Gateway
- `GET /actuator/health` - Health check
- `GET /auth/**` - Rutas hacia Auth-Service
- `GET /sentidos/**` - Rutas hacia Sentidos-Service
- `GET /lookup/**` - Rutas hacia Lookup-Service

## Dependencias de Arranque

Para que la autenticación funcione correctamente, los servicios deben arrancarse en este orden:

1. **auth-service** (8081) - Genera y valida tokens
2. **lookup-service** (8082) - Servicios de lookup
3. **sentidos-service** (8083) - Lógica de negocio principal
4. **gateway-service** (8085) - Punto de entrada (depende de los anteriores)
5. **login-frontend** (5171) - Interfaz de login
6. **sentidos-frontend** (5172) - Aplicación principal

Los servicios geoserver y tiles son independientes y pueden arrancar en cualquier momento.
