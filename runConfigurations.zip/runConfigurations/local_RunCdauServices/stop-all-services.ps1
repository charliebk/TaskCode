# =============================================================================
# stop-all-services.ps1
# Detiene todos los microservicios CDAU liberando los puertos correspondientes.
# Mata procesos por puerto y por nombre de JAR (para asegurar limpieza completa).
# Con -StopKafka tambien baja Kafka via docker-compose.
# =============================================================================
param(
    [switch]$StopKafka
)

$ErrorActionPreference = "Continue"

$ROOT_DIR = Split-Path -Parent (Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path))

Write-Host "==================================================" -ForegroundColor Cyan
Write-Host "  DETENIENDO TODOS LOS MICROSERVICIOS CDAU" -ForegroundColor Cyan
Write-Host "==================================================" -ForegroundColor Cyan
Write-Host ""

# -----------------------------------------------------------------------------
# Lista de servicios y sus puertos
# -----------------------------------------------------------------------------
$services = @(
    @{ Name = "auth-service";            Port = 8081; Jar = "auth-service-1.0.1.jar" },
    @{ Name = "lookup-service";          Port = 8082; Jar = "lookup-service-1.0.1.jar" },
    @{ Name = "sentidos-service";        Port = 8083; Jar = "sentidos-service-1.0.1.jar" },
    @{ Name = "gateway-service";         Port = 8085; Jar = "gateway-service-1.0.1.jar" },
    @{ Name = "cdau-tiles-service";      Port = 8086; Jar = "cdau-tiles-service-1.0.1.jar" },
    @{ Name = "geoserver-admin-service"; Port = 8090; Jar = "geoserver-admin-service-1.0.1.jar" },
    @{ Name = "geoserver-data-service";  Port = 8092; Jar = "geoserver-data-service-1.0.1.jar" }
)

# -----------------------------------------------------------------------------
# Helper: matar proceso por PID con feedback
# -----------------------------------------------------------------------------
function Stop-PidSafe {
    param([int]$ProcessId, [string]$Reason)
    try {
        $proc = Get-Process -Id $ProcessId -ErrorAction SilentlyContinue
        if ($proc) {
            $name = $proc.ProcessName
            Stop-Process -Id $ProcessId -Force -ErrorAction Stop
            Write-Host "    [KILL] PID $ProcessId ($name) - $Reason" -ForegroundColor Yellow
            return $true
        }
    } catch {
        Write-Host "    [WARN] No se pudo matar PID ${ProcessId}: $_" -ForegroundColor Red
    }
    return $false
}

# -----------------------------------------------------------------------------
# 1) Matar por puerto cada servicio
# -----------------------------------------------------------------------------
Write-Host "[1/3] Matando procesos por puerto..." -ForegroundColor Green
Write-Host ""

foreach ($svc in $services) {
    $name = $svc.Name
    $port = $svc.Port
    Write-Host "  -> $name (puerto $port)" -ForegroundColor White

    $conns = Get-NetTCPConnection -State Listen -LocalPort $port -ErrorAction SilentlyContinue
    if ($conns) {
        $pids = $conns | Select-Object -ExpandProperty OwningProcess -Unique
        foreach ($processId in $pids) {
            [void](Stop-PidSafe -ProcessId $processId -Reason "ocupaba puerto $port")
        }
    } else {
        Write-Host "    [OK]   Puerto $port ya estaba libre" -ForegroundColor DarkGray
    }
}

# -----------------------------------------------------------------------------
# 2) Matar por nombre de JAR (por si quedan procesos zombie sin puerto)
# -----------------------------------------------------------------------------
Write-Host ""
Write-Host "[2/3] Buscando procesos Java zombie por nombre de JAR..." -ForegroundColor Green
Write-Host ""

$javaProcesses = Get-CimInstance Win32_Process -Filter "Name = 'java.exe'" -ErrorAction SilentlyContinue
if ($javaProcesses) {
    foreach ($svc in $services) {
        $jar = $svc.Jar
        $matches = $javaProcesses | Where-Object { $_.CommandLine -and $_.CommandLine -like "*$jar*" }
        foreach ($m in $matches) {
            [void](Stop-PidSafe -ProcessId $m.ProcessId -Reason "JAR $jar")
        }
    }
} else {
    Write-Host "  [OK] No hay procesos java.exe en ejecucion" -ForegroundColor DarkGray
}

# -----------------------------------------------------------------------------
# 3) Verificacion final
# -----------------------------------------------------------------------------
Start-Sleep -Seconds 2
Write-Host ""
Write-Host "[3/3] Verificacion final de puertos..." -ForegroundColor Green
Write-Host ""

$anyBusy = $false
foreach ($svc in $services) {
    $port = $svc.Port
    $name = $svc.Name
    $conn = Get-NetTCPConnection -State Listen -LocalPort $port -ErrorAction SilentlyContinue
    if ($conn) {
        $busyPid = $conn.OwningProcess | Select-Object -First 1
        $proc = Get-Process -Id $busyPid -ErrorAction SilentlyContinue
        $procName = if ($proc) { $proc.ProcessName } else { "?" }
        Write-Host "  [BUSY] $name puerto $port -> PID $busyPid ($procName)" -ForegroundColor Red
        $anyBusy = $true
    } else {
        Write-Host "  [FREE] $name puerto $port" -ForegroundColor Green
    }
}

Write-Host ""
Write-Host "==================================================" -ForegroundColor Cyan
if ($anyBusy) {
    Write-Host "  ATENCION: algunos puertos siguen ocupados." -ForegroundColor Yellow
    Write-Host "  Pueden ser servicios externos (ej. GeoServer Windows Service)." -ForegroundColor Yellow
} else {
    Write-Host "  TODOS LOS PUERTOS LIBERADOS CORRECTAMENTE" -ForegroundColor Green
}
Write-Host "==================================================" -ForegroundColor Cyan

# -----------------------------------------------------------------------------
# 4) Opcional: bajar Kafka (docker-compose)
# -----------------------------------------------------------------------------
if ($StopKafka) {
    Write-Host ""
    Write-Host "[4/4] Bajando Kafka (docker-compose stop kafka kafka-ui)..." -ForegroundColor Green
    $composeFile = Join-Path $ROOT_DIR "docker-compose.yml"
    if (Test-Path $composeFile) {
        & docker compose -f $composeFile stop kafka kafka-ui
        if ($LASTEXITCODE -eq 0) {
            Write-Host "  [OK] Kafka detenido" -ForegroundColor Green
        } else {
            Write-Host "  [WARN] docker compose stop devolvio exit $LASTEXITCODE" -ForegroundColor Yellow
        }
    } else {
        Write-Host "  [SKIP] docker-compose.yml no encontrado en $ROOT_DIR" -ForegroundColor Yellow
    }
} else {
    Write-Host ""
    Write-Host "Nota: Kafka sigue corriendo (usa -StopKafka para bajarlo)." -ForegroundColor DarkGray
}
