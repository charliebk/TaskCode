﻿<#
.SYNOPSIS
  Arranca todos los microservicios CDAU + frontends (Vite).
  Antes de los backends levanta Kafka via docker-compose y espera al puerto 29092.

.PARAMETER NoBuild
  No ejecuta `mvn package`. Falla los servicios sin JAR.

.PARAMETER OnlyBackend
  Salta los frontends.

.PARAMETER OnlyFrontend
  Salta los backends.

.PARAMETER Profile
  Perfil Spring (default: dev).

.PARAMETER SkipKafka
  No arranca Kafka via docker-compose (asume que ya está corriendo).

.PARAMETER KafkaTimeoutSec
  Segundos a esperar a que Kafka responda en localhost:29092 (default: 60).
#>
param(
    [switch]$NoBuild,
    [switch]$OnlyBackend,
    [switch]$OnlyFrontend,
    [string]$Profile = "dev",
    [switch]$SkipKafka,
    [int]$KafkaTimeoutSec = 60
)

$ErrorActionPreference = "Stop"

function Write-ColorOutput($ForegroundColor) {
    $fc = $host.UI.RawUI.ForegroundColor
    $host.UI.RawUI.ForegroundColor = $ForegroundColor
    if ($args) { Write-Output $args }
    $host.UI.RawUI.ForegroundColor = $fc
}

# ---------- Rutas base ----------
$SCRIPT_DIR = Split-Path -Parent $MyInvocation.MyCommand.Path
$ROOT_DIR   = Split-Path -Parent (Split-Path -Parent (Split-Path -Parent $SCRIPT_DIR))
$LOGS_DIR   = Join-Path $ROOT_DIR "logs"
$PIDS_FILE  = Join-Path $ROOT_DIR ".running-services-pids.txt"

if (-not (Test-Path $LOGS_DIR)) { New-Item -ItemType Directory -Path $LOGS_DIR | Out-Null }
if (Test-Path $PIDS_FILE)        { Remove-Item $PIDS_FILE }

Write-ColorOutput Cyan "=================================================="
Write-ColorOutput Cyan "  Arrancando servicios CDAU (profile: $Profile)"
Write-ColorOutput Cyan "=================================================="
Write-Output ""
Write-ColorOutput Cyan "  Directorio raiz: $ROOT_DIR"
Write-Output ""

# ---------- Maven bundled fallback ----------
function Find-Maven {
    $cmd = Get-Command mvn -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    $candidates = @()
    $jb = "C:\Program Files\JetBrains"
    if (Test-Path $jb) {
        $candidates += Get-ChildItem $jb -Directory -ErrorAction SilentlyContinue |
            ForEach-Object { Join-Path $_.FullName "plugins\maven\lib\maven3\bin\mvn.cmd" }
    }
    $candidates += @(
        "C:\Program Files\Apache\maven\bin\mvn.cmd",
        "C:\apache-maven\bin\mvn.cmd",
        "$env:USERPROFILE\scoop\apps\maven\current\bin\mvn.cmd"
    )
    foreach ($c in $candidates) { if (Test-Path $c) { return $c } }
    return $null
}

function Resolve-Jar {
    param([string]$Module)
    $pattern = Join-Path $ROOT_DIR "$Module\target\$Module-*.jar"
    Get-ChildItem -Path $pattern -ErrorAction SilentlyContinue |
        Where-Object {
            $_.Name -notmatch "\.original$" -and
            $_.Name -notmatch "-sources\.jar$" -and
            $_.Name -notmatch "-javadoc\.jar$"
        } |
        Sort-Object LastWriteTime -Descending |
        Select-Object -First 1
}

# ---------- Libera puertos ocupados por arranques previos ----------
function Free-Port {
    param([int]$Port, [string]$Label)
    $conns = Get-NetTCPConnection -State Listen -LocalPort $Port -ErrorAction SilentlyContinue
    foreach ($c in $conns) {
        $proc = Get-Process -Id $c.OwningProcess -ErrorAction SilentlyContinue
        # Respeta GeoServer externo y cualquier proceso que no sea java/node
        if ($proc -and $proc.ProcessName -notin @("java","node")) {
            Write-ColorOutput Yellow "  [KEEP] Puerto $Port ocupado por $($proc.ProcessName) (PID $($proc.Id)) - no se mata"
            continue
        }
        try {
            Stop-Process -Id $c.OwningProcess -Force -ErrorAction Stop
            Write-ColorOutput Yellow "  [FREE] Puerto $Port liberado (mate $($proc.ProcessName) PID $($proc.Id))"
        } catch {
            Write-ColorOutput Red "  [WARN] No se pudo matar PID $($c.OwningProcess) en puerto $Port"
        }
    }
}
function Start-BackgroundProcess {
    param(
        [Parameter(Mandatory)] [string]$Name,
        [Parameter(Mandatory)] [string]$WorkingDir,
        [Parameter(Mandatory)] [string]$Command,
        [string[]]$ArgList = @()
    )
    Write-ColorOutput Yellow "Iniciando $Name..."

    $stdout = Join-Path $LOGS_DIR "$Name.log"
    $stderr = Join-Path $LOGS_DIR "$Name.err.log"

    $params = @{
        FilePath               = $Command
        WorkingDirectory       = $WorkingDir
        RedirectStandardOutput = $stdout
        RedirectStandardError  = $stderr
        WindowStyle            = "Hidden"
        PassThru               = $true
    }
    if ($ArgList.Count -gt 0) { $params.ArgumentList = $ArgList }

    try {
        $process = Start-Process @params
    } catch {
        Write-ColorOutput Red "  [ERROR] No se pudo iniciar $Name : $($_.Exception.Message)"
        return $null
    }

    "$($process.Id)|$Name" | Out-File -FilePath $PIDS_FILE -Append -Encoding utf8
    Write-ColorOutput Green "  [OK] $Name iniciado (PID: $($process.Id)) -> logs\$Name.log"
    return $process
}

# ---------- Servicios ----------
$backendServices = @(
    @{ Name = "auth-service";            Port = 8081 },
    @{ Name = "lookup-service";          Port = 8082 },
    @{ Name = "sentidos-service";        Port = 8083 },
    @{ Name = "gateway-service";         Port = 8085 },
    @{ Name = "geoserver-admin-service"; Port = 8090 },
    @{ Name = "geoserver-data-service";  Port = 8092 },
    @{ Name = "cdau-tiles-service";      Port = 8080 }
)
$frontends = @(
    @{ Name = "login-frontend";    Dir = "login-frontend";    Port = 5171 },
    @{ Name = "sentidos-frontend"; Dir = "sentidos-frontend"; Port = 5172 }
)

# ---------- PASO -1: Kafka via docker-compose ----------
function Wait-ForPort {
    param(
        [Parameter(Mandatory)] [string]$ComputerName,
        [Parameter(Mandatory)] [int]$Port,
        [int]$TimeoutSec = 60
    )
    $deadline = (Get-Date).AddSeconds($TimeoutSec)
    while ((Get-Date) -lt $deadline) {
        $ok = $false
        try {
            $ok = Test-NetConnection -ComputerName $ComputerName -Port $Port -InformationLevel Quiet -WarningAction SilentlyContinue
        } catch {
            $ok = $false
        }
        if ($ok) { return $true }
        Start-Sleep -Seconds 1
    }
    return $false
}

if (-not $OnlyFrontend -and -not $SkipKafka) {
    Write-ColorOutput Cyan "PASO -1: Arrancando Kafka (docker-compose)..."
    Write-ColorOutput Cyan "--------------------------------------------------"

    $composeFile = Join-Path $ROOT_DIR "docker-compose.yml"
    if (-not (Test-Path $composeFile)) {
        Write-ColorOutput Red "  [ERROR] No se encontro docker-compose.yml en $ROOT_DIR"
        exit 1
    }

    $dockerCmd = Get-Command docker -ErrorAction SilentlyContinue
    if (-not $dockerCmd) {
        Write-ColorOutput Red "  [ERROR] docker no encontrado en PATH. Instala Docker Desktop o usa -SkipKafka."
        exit 1
    }

    Write-ColorOutput Yellow "  Levantando contenedores kafka y kafka-ui..."
    & docker compose -f $composeFile up -d kafka kafka-ui
    if ($LASTEXITCODE -ne 0) {
        Write-ColorOutput Red "  [ERROR] docker compose up fallo (exit $LASTEXITCODE)."
        exit $LASTEXITCODE
    }

    Write-ColorOutput Yellow "  Esperando a que Kafka responda en localhost:29092 (timeout=${KafkaTimeoutSec}s)..."
    if (Wait-ForPort -ComputerName "localhost" -Port 29092 -TimeoutSec $KafkaTimeoutSec) {
        Write-ColorOutput Green "  [OK] Kafka esta listo en localhost:29092"
        Write-ColorOutput White "       Kafka UI: http://localhost:8090"
    } else {
        Write-ColorOutput Red "  [ERROR] Kafka no respondio en $KafkaTimeoutSec segundos."
        Write-ColorOutput Red "         Revisa: docker logs kafka"
        exit 1
    }
    Write-Output ""
}

# ---------- PASO 0: build si faltan JAR ----------
if (-not $OnlyFrontend) {
    $missingBefore = $backendServices | Where-Object { -not (Resolve-Jar -Module $_.Name) }
    if ($missingBefore.Count -gt 0 -and -not $NoBuild) {
        Write-ColorOutput Cyan "PASO 0: Construyendo modulos Maven (faltan $($missingBefore.Count) JAR)..."
        Write-ColorOutput Cyan "--------------------------------------------------"
        $mvn = Find-Maven
        if (-not $mvn) {
            Write-ColorOutput Red "  [ERROR] No se encontro Maven. Instalalo o usa -NoBuild si los JAR ya existen."
            exit 1
        }
        Write-ColorOutput Cyan "  Maven: $mvn"
        & $mvn -f (Join-Path $ROOT_DIR "pom.xml") -DskipTests clean package
        if ($LASTEXITCODE -ne 0) {
            Write-ColorOutput Red "  [ERROR] mvn package fallo (exit $LASTEXITCODE)."
            exit $LASTEXITCODE
        }
        Write-ColorOutput Green "  [OK] Build completado"
        Write-Output ""
    }
}

# ---------- PASO 1: backends ----------
if (-not $OnlyFrontend) {
    Write-ColorOutput Cyan "PASO 1: Arrancando servicios backend (profile=$Profile)..."
    Write-ColorOutput Cyan "--------------------------------------------------"
    Write-ColorOutput Yellow "  Liberando puertos ocupados..."
    foreach ($svc in $backendServices) { Free-Port -Port $svc.Port -Label $svc.Name }
    Start-Sleep -Seconds 1
    $started = 0
    foreach ($svc in $backendServices) {
        $jar = Resolve-Jar -Module $svc.Name
        if ($jar) {
            $javaArgs = @(
                "-Dspring.profiles.active=$Profile",
                "-Dspring.devtools.restart.enabled=false",
                "-jar", $jar.FullName
            )
            Start-BackgroundProcess -Name $svc.Name `
                                    -WorkingDir (Join-Path $ROOT_DIR $svc.Name) `
                                    -Command "java" `
                                    -ArgList $javaArgs | Out-Null
            Start-Sleep -Seconds 2
            $started++
        } else {
            Write-ColorOutput Yellow "  [SKIP] JAR no encontrado para $($svc.Name)"
        }
    }
    Write-ColorOutput Cyan "  Servicios backend iniciados: $started de $($backendServices.Count)"
    Write-Output ""
}

# ---------- PASO 2: frontends ----------
if (-not $OnlyBackend) {
    Write-ColorOutput Cyan "PASO 2: Arrancando frontends (Vite)..."
    Write-ColorOutput Cyan "--------------------------------------------------"
    Write-ColorOutput Yellow "  Liberando puertos ocupados..."
    foreach ($fe in $frontends) { Free-Port -Port $fe.Port -Label $fe.Name }
    Start-Sleep -Seconds 1
    foreach ($fe in $frontends) {
        $feDir = Join-Path $ROOT_DIR $fe.Dir
        if (-not (Test-Path $feDir)) {
            Write-ColorOutput Yellow "  [SKIP] $($fe.Name): directorio no encontrado"
            continue
        }
        if (-not (Test-Path (Join-Path $feDir "node_modules"))) {
            Write-ColorOutput Yellow "Instalando dependencias de $($fe.Name)..."
            Push-Location $feDir
            cmd.exe /c npm install
            Pop-Location
        }
        # Start-Process con RedirectStandardOutput fuerza UseShellExecute=false, que no resuelve .cmd via PATHEXT.
        # Por eso envolvemos con cmd.exe /c para que npm.cmd se encuentre.
        Start-BackgroundProcess -Name $fe.Name `
                                -WorkingDir $feDir `
                                -Command "cmd.exe" `
                                -ArgList @("/c", "npm", "run", "dev") | Out-Null
        Start-Sleep -Seconds 3
    }
    Write-Output ""
}

# ---------- Resumen ----------
Write-ColorOutput Cyan "=================================================="
Write-ColorOutput Green "  [OK] Servicios iniciados"
Write-ColorOutput Cyan "=================================================="
Write-Output ""
Write-ColorOutput White "URLs:"
if (-not $OnlyFrontend -and -not $SkipKafka) {
    Write-ColorOutput White "  Infra:"
    Write-ColorOutput White ("    - {0,-24} http://localhost:8090" -f "kafka-ui")
    Write-ColorOutput White ("    - {0,-24} localhost:29092" -f "kafka-broker")
}
if (-not $OnlyBackend) {
    Write-ColorOutput White "  Frontend:"
    foreach ($fe in $frontends) { Write-ColorOutput White ("    - {0,-24} http://localhost:{1}" -f $fe.Name, $fe.Port) }
}
if (-not $OnlyFrontend) {
    Write-ColorOutput White "  Backend:"
    foreach ($svc in $backendServices) { Write-ColorOutput White ("    - {0,-24} http://localhost:{1}" -f $svc.Name, $svc.Port) }
}
Write-Output ""
Write-ColorOutput Yellow "Logs:  $LOGS_DIR"
Write-ColorOutput Yellow "PIDs:  $PIDS_FILE"
Write-ColorOutput Yellow "Stop:  .\.idea\runConfigurations\local_RunCdauServices\stop-all-services.ps1"
Write-Output ""
Write-ColorOutput Yellow "Espera ~20-40s a que arranque todo. Revisa logs\<servicio>.log si algo no responde."

if (-not $OnlyBackend) {
    Start-Sleep -Seconds 5
    Write-ColorOutput Cyan "Abriendo navegador con sentidos-frontend..."
    Start-Process "http://localhost:5172"
}

